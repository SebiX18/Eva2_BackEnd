"""
=========================================
Módulo: clinica.urls
Contexto: EVA2 - Salud Vital Ltda.
Descripción:
- Rutas DRF usando DefaultRouter.
=========================================
"""
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    SeguroSaludViewSet, EspecialidadViewSet, PacienteViewSet, MedicoViewSet,
    ConsultaMedicaViewSet, TratamientoViewSet, MedicamentoViewSet,
    RecetaMedicaViewSet, RecetaMedicamentoViewSet
)


router = DefaultRouter()
router.register(r"seguros", SeguroSaludViewSet)
router.register(r"especialidades", EspecialidadViewSet)
router.register(r"pacientes", PacienteViewSet)
router.register(r"medicos", MedicoViewSet)
router.register(r"consultas", ConsultaMedicaViewSet)
router.register(r"tratamientos", TratamientoViewSet)
router.register(r"medicamentos", MedicamentoViewSet)
router.register(r"recetas", RecetaMedicaViewSet)
router.register(r"receta-detalles", RecetaMedicamentoViewSet)

urlpatterns = [
    path("", include(router.urls)),
]

