from django.contrib import admin
from .models import (
    SeguroSalud, Especialidad, Paciente, Medico,
    ConsultaMedica, Tratamiento, Medicamento,
    RecetaMedica, RecetaMedicamento
)

# --- Inlines (para CRUD más cómodo) ---
class TratamientoInline(admin.TabularInline):
    model = Tratamiento
    extra = 1

class RecetaMedicamentoInline(admin.TabularInline):
    model = RecetaMedicamento
    extra = 1
    autocomplete_fields = ('medicamento',)

# --- Catálogos simples ---
@admin.register(SeguroSalud)
class SeguroSaludAdmin(admin.ModelAdmin):
    list_display = ('nombre',)
    search_fields = ('nombre',)

@admin.register(Especialidad)
class EspecialidadAdmin(admin.ModelAdmin):
    list_display = ('nombre',)
    search_fields = ('nombre',)

@admin.register(Medicamento)
class MedicamentoAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'presentacion', 'dosis_sugerida')
    search_fields = ('nombre', 'presentacion', 'dosis_sugerida')

# --- Entidades principales ---
@admin.register(Paciente)
class PacienteAdmin(admin.ModelAdmin):
    list_display = ('rut', 'apellidos', 'nombres', 'sexo', 'seguro')
    search_fields = ('rut', 'nombres', 'apellidos', 'email', 'telefono')
    list_filter = ('sexo', 'seguro')
    autocomplete_fields = ('seguro',)

@admin.register(Medico)
class MedicoAdmin(admin.ModelAdmin):
    list_display = ('rut', 'apellidos', 'nombres', 'especialidad', 'telefono')
    search_fields = ('rut', 'nombres', 'apellidos', 'email', 'telefono')
    list_filter = ('especialidad',)
    autocomplete_fields = ('especialidad',)

@admin.register(ConsultaMedica)
class ConsultaMedicaAdmin(admin.ModelAdmin):
    list_display = ('id', 'fecha_hora', 'paciente', 'medico', 'especialidad', 'estado')
    search_fields = (
        'paciente__rut', 'paciente__nombres', 'paciente__apellidos',
        'medico__rut', 'medico__nombres', 'medico__apellidos',
        'motivo', 'diagnostico'
    )
    list_filter = ('estado', 'especialidad', 'fecha_hora')
    date_hierarchy = 'fecha_hora'
    autocomplete_fields = ('paciente', 'medico', 'especialidad')
    inlines = [TratamientoInline]

@admin.register(RecetaMedica)
class RecetaMedicaAdmin(admin.ModelAdmin):
    list_display = ('id', 'consulta', 'fecha')
    search_fields = ('consulta__paciente__rut', 'consulta__medico__rut')
    date_hierarchy = 'fecha'
    autocomplete_fields = ('consulta',)
    inlines = [RecetaMedicamentoInline]

# Register your models here.
