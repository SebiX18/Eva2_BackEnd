# clinica/forms.py
from django import forms
from .models import (
    SeguroSalud, Especialidad, Paciente, Medico,
    ConsultaMedica, Tratamiento, Medicamento,
    RecetaMedica, RecetaMedicamento
)

DATE_INPUT = {"class": "input", "type": "date"}
DT_INPUT   = {"class": "input", "type": "datetime-local"}  # para ConsultaMedica

class SeguroForm(forms.ModelForm):
    class Meta:
        model = SeguroSalud
        fields = "__all__"

class EspecialidadForm(forms.ModelForm):
    class Meta:
        model = Especialidad
        fields = "__all__"

class PacienteForm(forms.ModelForm):
    class Meta:
        model = Paciente
        fields = "__all__"
        widgets = {
            "fecha_nacimiento": forms.DateInput(attrs=DATE_INPUT),
        }

class MedicoForm(forms.ModelForm):
    class Meta:
        model = Medico
        fields = "__all__"

class MedicamentoForm(forms.ModelForm):
    class Meta:
        model = Medicamento
        fields = "__all__"

class ConsultaForm(forms.ModelForm):
    class Meta:
        model = ConsultaMedica
        fields = "__all__"
        widgets = {
            "fecha_hora": forms.DateTimeInput(attrs=DT_INPUT),
        }

class TratamientoForm(forms.ModelForm):
    class Meta:
        model = Tratamiento
        fields = "__all__"

class RecetaForm(forms.ModelForm):
    class Meta:
        model = RecetaMedica
        fields = "__all__"
        widgets = {
            "fecha": forms.DateInput(attrs=DATE_INPUT),
        }

class RecetaDetalleForm(forms.ModelForm):
    class Meta:
        model = RecetaMedicamento
        fields = "__all__"
