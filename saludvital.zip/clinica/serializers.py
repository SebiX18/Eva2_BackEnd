"""
=========================================
Módulo: clinica.serializers
Contexto: EVA2 - Salud Vital Ltda.
Descripción:
- Serializadores DRF para exponer CRUD de todas
  las entidades del modelo clínico.
=========================================
"""
from rest_framework import serializers
from .models import (
    SeguroSalud, Especialidad, Paciente, Medico,
    ConsultaMedica, Tratamiento, Medicamento,
    RecetaMedica, RecetaMedicamento
)

# --- Catálogos simples ---
class SeguroSaludSerializer(serializers.ModelSerializer):
    class Meta:
        model = SeguroSalud
        fields = "__all__"

class EspecialidadSerializer(serializers.ModelSerializer):
    class Meta:
        model = Especialidad
        fields = "__all__"

class MedicamentoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Medicamento
        fields = "__all__"

# --- Entidades principales ---
class PacienteSerializer(serializers.ModelSerializer):
    seguro_nombre = serializers.StringRelatedField(source="seguro", read_only=True)

    class Meta:
        model = Paciente
        fields = [
            "id", "rut", "nombres", "apellidos", "sexo", "fecha_nacimiento",
            "email", "telefono", "direccion", "seguro", "seguro_nombre"
        ]

class MedicoSerializer(serializers.ModelSerializer):
    especialidad_nombre = serializers.StringRelatedField(source="especialidad", read_only=True)

    class Meta:
        model = Medico
        fields = [
            "id", "rut", "nombres", "apellidos", "email", "telefono",
            "especialidad", "especialidad_nombre"
        ]

class ConsultaMedicaSerializer(serializers.ModelSerializer):
    paciente_str = serializers.StringRelatedField(source="paciente", read_only=True)
    medico_str = serializers.StringRelatedField(source="medico", read_only=True)
    especialidad_nombre = serializers.StringRelatedField(source="especialidad", read_only=True)

    class Meta:
        model = ConsultaMedica
        fields = [
            "id", "paciente", "paciente_str", "medico", "medico_str",
            "especialidad", "especialidad_nombre",
            "fecha_hora", "motivo", "diagnostico", "estado"
        ]

class TratamientoSerializer(serializers.ModelSerializer):
    consulta_str = serializers.StringRelatedField(source="consulta", read_only=True)

    class Meta:
        model = Tratamiento
        fields = ["id", "consulta", "consulta_str", "nombre", "indicaciones"]

class RecetaMedicamentoSerializer(serializers.ModelSerializer):
    medicamento_nombre = serializers.StringRelatedField(source="medicamento", read_only=True)

    class Meta:
        model = RecetaMedicamento
        fields = ["id", "receta", "medicamento", "medicamento_nombre", "dosis", "frecuencia", "duracion"]

class RecetaMedicaSerializer(serializers.ModelSerializer):
    consulta_str = serializers.StringRelatedField(source="consulta", read_only=True)

    class Meta:
        model = RecetaMedica
        fields = ["id", "consulta", "consulta_str", "fecha", "indicaciones_generales"]
