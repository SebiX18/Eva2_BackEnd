"""
=========================================
Módulo: clinica.views
Contexto: EVA2 - Salud Vital Ltda.
Descripción:
- ViewSets DRF para CRUD de todas las entidades.
- Incluye filtros y búsquedas con django-filter.
=========================================
"""
from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticatedOrReadOnly
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter

from .models import (
    SeguroSalud, Especialidad, Paciente, Medico,
    ConsultaMedica, Tratamiento, Medicamento,
    RecetaMedica, RecetaMedicamento
)
from .serializers import (
    SeguroSaludSerializer, EspecialidadSerializer, PacienteSerializer, MedicoSerializer,
    ConsultaMedicaSerializer, TratamientoSerializer, MedicamentoSerializer,
    RecetaMedicaSerializer, RecetaMedicamentoSerializer
)


class BaseViewSet(viewsets.ModelViewSet):
    """Config común: permisos, filtros y ordenamiento."""
    permission_classes = [IsAuthenticatedOrReadOnly]
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]


# --- Catálogos ---
class SeguroSaludViewSet(BaseViewSet):
    queryset = SeguroSalud.objects.all().order_by("nombre")
    serializer_class = SeguroSaludSerializer
    search_fields = ["nombre"]
    ordering_fields = ["nombre"]

class EspecialidadViewSet(BaseViewSet):
    queryset = Especialidad.objects.all().order_by("nombre")
    serializer_class = EspecialidadSerializer
    search_fields = ["nombre"]
    ordering_fields = ["nombre"]

class MedicamentoViewSet(BaseViewSet):
    queryset = Medicamento.objects.all().order_by("nombre")
    serializer_class = MedicamentoSerializer
    search_fields = ["nombre", "presentacion", "dosis_sugerida"]
    ordering_fields = ["nombre"]


# --- Entidades principales ---
class PacienteViewSet(BaseViewSet):
    queryset = (
        Paciente.objects.select_related("seguro")
        .all().order_by("apellidos", "nombres")
    )
    serializer_class = PacienteSerializer
    filterset_fields = ["sexo", "seguro"]          # filtros exactos
    search_fields = ["rut", "nombres", "apellidos", "email", "telefono", "direccion"]
    ordering_fields = ["apellidos", "nombres", "rut"]

class MedicoViewSet(BaseViewSet):
    queryset = (
        Medico.objects.select_related("especialidad")
        .all().order_by("apellidos", "nombres")
    )
    serializer_class = MedicoSerializer
    filterset_fields = ["especialidad"]
    search_fields = ["rut", "nombres", "apellidos", "email", "telefono", "especialidad__nombre"]
    ordering_fields = ["apellidos", "nombres", "rut"]

class ConsultaMedicaViewSet(BaseViewSet):
    queryset = (
        ConsultaMedica.objects.select_related("paciente", "medico", "especialidad")
        .all().order_by("-fecha_hora")
    )
    serializer_class = ConsultaMedicaSerializer
    filterset_fields = ["medico", "paciente", "especialidad", "estado"]
    search_fields = [
        "motivo", "diagnostico",
        "paciente__rut", "paciente__nombres", "paciente__apellidos",
        "medico__rut", "medico__nombres", "medico__apellidos",
        "especialidad__nombre"
    ]
    ordering_fields = ["fecha_hora"]

class TratamientoViewSet(BaseViewSet):
    queryset = Tratamiento.objects.select_related("consulta").all()
    serializer_class = TratamientoSerializer
    filterset_fields = ["consulta"]
    search_fields = ["nombre", "indicaciones", "consulta__paciente__apellidos"]
    ordering_fields = ["id"]

class RecetaMedicaViewSet(BaseViewSet):
    queryset = RecetaMedica.objects.select_related("consulta").all().order_by("-fecha")
    serializer_class = RecetaMedicaSerializer
    filterset_fields = ["consulta"]
    search_fields = ["consulta__paciente__apellidos", "consulta__medico__apellidos"]
    ordering_fields = ["fecha"]

class RecetaMedicamentoViewSet(BaseViewSet):
    queryset = RecetaMedicamento.objects.select_related("receta", "medicamento").all()
    serializer_class = RecetaMedicamentoSerializer
    filterset_fields = ["receta", "medicamento"]
    search_fields = ["medicamento__nombre", "dosis", "frecuencia", "duracion"]
    ordering_fields = ["id"]

# Create your views here.
