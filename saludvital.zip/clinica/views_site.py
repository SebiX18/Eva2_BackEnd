# clinica/views_site.py
from django.shortcuts import render, redirect
from django.db.models import Q
from django.utils.dateparse import parse_date
from django.urls import reverse_lazy
from django.views.generic import CreateView, UpdateView, DeleteView
from django.contrib import messages
from django.db.models.deletion import ProtectedError
try:
    # Django 4+ puede tener RESTRICT
    from django.db.models.deletion import RestrictedError
except ImportError:
    class RestrictedError(Exception):
        pass

from .models import (
    SeguroSalud, Especialidad, Paciente, Medico,
    Medicamento, ConsultaMedica, Tratamiento,
    RecetaMedica, RecetaMedicamento
)
from .forms import (
    SeguroForm, EspecialidadForm, PacienteForm, MedicoForm,
    MedicamentoForm, ConsultaForm, TratamientoForm,
    RecetaForm, RecetaDetalleForm
)

# -------------------------
# Páginas públicas
# -------------------------
def home(request):
    return render(request, "home.html")

def quienes_somos(request):
    return render(request, "quienes_somos.html")

def servicios_page(request):
    return render(request, "servicios.html")

def contacto(request):
    return render(request, "contacto.html")

def datos(request):
    """Página índice que enlaza a todas las tablas HTML."""
    return render(request, "datos.html")


# Utilidad
def _clean(s):
    return (s or "").strip()


# -------------------------
# Listados con filtros
# -------------------------
def seguros_list(request):
    q = _clean(request.GET.get("q"))
    qs = SeguroSalud.objects.all().order_by("nombre")
    if q:
        qs = qs.filter(nombre__icontains=q)
    return render(request, "data/seguros.html", {"seguros": qs, "q": q})


def especialidades_list(request):
    q = _clean(request.GET.get("q"))
    qs = Especialidad.objects.all().order_by("nombre")
    if q:
        qs = qs.filter(Q(nombre__icontains=q) | Q(descripcion__icontains=q))
    return render(request, "data/especialidades.html", {"especialidades": qs, "q": q})


def pacientes_list(request):
    q = _clean(request.GET.get("q"))           # rut/nombres/apellidos
    seguro_id = _clean(request.GET.get("seguro"))
    sexo = _clean(request.GET.get("sexo"))

    qs = (Paciente.objects
          .select_related("seguro")
          .all().order_by("apellidos", "nombres"))

    if q:
        qs = qs.filter(
            Q(rut__icontains=q) |
            Q(nombres__icontains=q) |
            Q(apellidos__icontains=q)
        )
    if seguro_id:
        qs = qs.filter(seguro_id=seguro_id)
    if sexo:
        qs = qs.filter(sexo=sexo)

    ctx = {
        "pacientes": qs,
        "seguros": SeguroSalud.objects.all().order_by("nombre"),
        "q": q, "seguro_selected": seguro_id, "sexo_selected": sexo,
    }
    return render(request, "data/pacientes.html", ctx)


def medicos_list(request):
    q = _clean(request.GET.get("q"))           # rut/nombres/apellidos
    especialidad_id = _clean(request.GET.get("especialidad"))

    qs = (Medico.objects
          .select_related("especialidad")
          .all().order_by("apellidos", "nombres"))

    if q:
        qs = qs.filter(
            Q(rut__icontains=q) |
            Q(nombres__icontains=q) |
            Q(apellidos__icontains=q)
        )
    if especialidad_id:
        qs = qs.filter(especialidad_id=especialidad_id)

    ctx = {
        "medicos": qs,
        "especialidades": Especialidad.objects.all().order_by("nombre"),
        "q": q, "especialidad_selected": especialidad_id,
    }
    return render(request, "data/medicos.html", ctx)


def medicamentos_list(request):
    q = _clean(request.GET.get("q"))
    qs = Medicamento.objects.all().order_by("nombre")
    if q:
        qs = qs.filter(
            Q(nombre__icontains=q) |
            Q(presentacion__icontains=q) |
            Q(dosis_sugerida__icontains=q)
        )
    return render(request, "data/medicamentos.html", {"medicamentos": qs, "q": q})


def consultas_list(request):
    q = _clean(request.GET.get("q"))           # paciente/medico/rut
    estado = _clean(request.GET.get("estado"))
    d_from = parse_date(_clean(request.GET.get("desde")))
    d_to = parse_date(_clean(request.GET.get("hasta")))

    qs = (ConsultaMedica.objects
          .select_related("paciente", "medico", "especialidad")
          .all().order_by("-fecha_hora"))

    if q:
        qs = qs.filter(
            Q(paciente__nombres__icontains=q) |
            Q(paciente__apellidos__icontains=q) |
            Q(paciente__rut__icontains=q) |
            Q(medico__nombres__icontains=q) |
            Q(medico__apellidos__icontains=q) |
            Q(medico__rut__icontains=q)
        )
    if estado:
        qs = qs.filter(estado=estado)
    if d_from:
        qs = qs.filter(fecha_hora__date__gte=d_from)
    if d_to:
        qs = qs.filter(fecha_hora__date__lte=d_to)

    # Obtener choices del campo estado de forma segura
    estado_choices = getattr(ConsultaMedica._meta.get_field("estado"), "choices", [])

    ctx = {
        "consultas": qs,
        "q": q, "estado_selected": estado,
        "desde": request.GET.get("desde") or "",
        "hasta": request.GET.get("hasta") or "",
        "ESTADOS": estado_choices,
    }
    return render(request, "data/consultas.html", ctx)


def tratamientos_list(request):
    q = _clean(request.GET.get("q"))  # por nombre/indicaciones, paciente/medico
    qs = (Tratamiento.objects
          .select_related("consulta", "consulta__paciente", "consulta__medico")
          .all().order_by("id"))
    if q:
        qs = qs.filter(
            Q(nombre__icontains=q) |
            Q(indicaciones__icontains=q) |
            Q(consulta__paciente__nombres__icontains=q) |
            Q(consulta__paciente__apellidos__icontains=q) |
            Q(consulta__medico__nombres__icontains=q) |
            Q(consulta__medico__apellidos__icontains=q)
        )
    return render(request, "data/tratamientos.html", {"tratamientos": qs, "q": q})


def recetas_list(request):
    q = _clean(request.GET.get("q"))   # paciente/medico
    d_from = parse_date(_clean(request.GET.get("desde")))
    d_to = parse_date(_clean(request.GET.get("hasta")))

    qs = (RecetaMedica.objects
          .select_related("consulta", "consulta__paciente", "consulta__medico")
          .all().order_by("-fecha"))

    if q:
        qs = qs.filter(
            Q(consulta__paciente__nombres__icontains=q) |
            Q(consulta__paciente__apellidos__icontains=q) |
            Q(consulta__paciente__rut__icontains=q) |
            Q(consulta__medico__nombres__icontains=q) |
            Q(consulta__medico__apellidos__icontains=q) |
            Q(consulta__medico__rut__icontains=q)
        )
    if d_from:
        qs = qs.filter(fecha__gte=d_from)
    if d_to:
        qs = qs.filter(fecha__lte=d_to)

    ctx = {
        "recetas": qs,
        "q": q,
        "desde": request.GET.get("desde") or "",
        "hasta": request.GET.get("hasta") or "",
    }
    return render(request, "data/recetas.html", ctx)


def receta_detalles_list(request):
    q = _clean(request.GET.get("q"))  # paciente/medicamento
    qs = (RecetaMedicamento.objects
          .select_related("receta", "medicamento",
                          "receta__consulta", "receta__consulta__paciente",
                          "receta__consulta__medico")
          .all().order_by("id"))
    if q:
        qs = qs.filter(
            Q(medicamento__nombre__icontains=q) |
            Q(receta__consulta__paciente__nombres__icontains=q) |
            Q(receta__consulta__paciente__apellidos__icontains=q)
        )
    return render(request, "data/receta_detalles.html", {"items": qs, "q": q})


# -------------------------
# CRUD genérico (Create / Update / Delete)
# -------------------------
class BaseCreate(CreateView):
    template_name = "data/form.html"
    success_url = reverse_lazy("home")
    title = "Crear"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["title"] = self.title
        ctx["cancel_url"] = self.success_url
        return ctx

    def form_valid(self, form):
        messages.success(self.request, "Registro creado correctamente.")
        return super().form_valid(form)


class BaseUpdate(UpdateView):
    template_name = "data/form.html"
    success_url = reverse_lazy("home")
    title = "Editar"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["title"] = self.title
        ctx["cancel_url"] = self.success_url
        return ctx

    def form_valid(self, form):
        messages.success(self.request, "Cambios guardados correctamente.")
        return super().form_valid(form)


class BaseDelete(DeleteView):
    """
    DeleteView: Django llama post() -> self.object.delete().
    Capturamos aquí Protected/Restricted para no romper la UI.
    """
    template_name = "data/confirm_delete.html"
    success_url = reverse_lazy("home")
    title = "Eliminar"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["title"] = self.title
        ctx["cancel_url"] = self.success_url
        return ctx

    def post(self, request, *args, **kwargs):
        self.object = self.get_object()
        try:
            self.object.delete()
            messages.success(request, "Registro eliminado.")
        except (ProtectedError, RestrictedError):
            messages.error(
                request,
                "No se puede eliminar porque existen registros relacionados "
                "(por ejemplo, consultas/recetas). Elimina primero los dependientes."
            )
        return redirect(self.get_success_url())


# ------- SeguroSalud -------
class SeguroCreate(BaseCreate):
    form_class = SeguroForm
    success_url = reverse_lazy("seguros_list")
    title = "Nuevo seguro de salud"

class SeguroUpdate(BaseUpdate):
    form_class = SeguroForm
    success_url = reverse_lazy("seguros_list")
    title = "Editar seguro de salud"

class SeguroDelete(BaseDelete):
    model = SeguroSalud
    success_url = reverse_lazy("seguros_list")
    title = "Eliminar seguro de salud"


# ------- Especialidad -------
class EspecialidadCreate(BaseCreate):
    form_class = EspecialidadForm
    success_url = reverse_lazy("especialidades_list")
    title = "Nueva especialidad"

class EspecialidadUpdate(BaseUpdate):
    form_class = EspecialidadForm
    success_url = reverse_lazy("especialidades_list")
    title = "Editar especialidad"

class EspecialidadDelete(BaseDelete):
    model = Especialidad
    success_url = reverse_lazy("especialidades_list")
    title = "Eliminar especialidad"


# ------- Paciente -------
class PacienteCreate(BaseCreate):
    form_class = PacienteForm
    success_url = reverse_lazy("pacientes_list")
    title = "Nuevo paciente"

class PacienteUpdate(BaseUpdate):
    form_class = PacienteForm
    success_url = reverse_lazy("pacientes_list")
    title = "Editar paciente"

class PacienteDelete(BaseDelete):
    model = Paciente
    success_url = reverse_lazy("pacientes_list")
    title = "Eliminar paciente"


# ------- Médico -------
class MedicoCreate(BaseCreate):
    form_class = MedicoForm
    success_url = reverse_lazy("medicos_list")
    title = "Nuevo médico"

class MedicoUpdate(BaseUpdate):
    form_class = MedicoForm
    success_url = reverse_lazy("medicos_list")
    title = "Editar médico"

class MedicoDelete(BaseDelete):
    model = Medico
    success_url = reverse_lazy("medicos_list")
    title = "Eliminar médico"


# ------- Medicamento -------
class MedicamentoCreate(BaseCreate):
    form_class = MedicamentoForm
    success_url = reverse_lazy("medicamentos_list")
    title = "Nuevo medicamento"

class MedicamentoUpdate(BaseUpdate):
    form_class = MedicamentoForm
    success_url = reverse_lazy("medicamentos_list")
    title = "Editar medicamento"

class MedicamentoDelete(BaseDelete):
    model = Medicamento
    success_url = reverse_lazy("medicamentos_list")
    title = "Eliminar medicamento"


# ------- ConsultaMedica -------
class ConsultaCreate(BaseCreate):
    form_class = ConsultaForm
    success_url = reverse_lazy("consultas_list")
    title = "Nueva consulta médica"

class ConsultaUpdate(BaseUpdate):
    form_class = ConsultaForm
    success_url = reverse_lazy("consultas_list")
    title = "Editar consulta médica"

class ConsultaDelete(BaseDelete):
    model = ConsultaMedica
    success_url = reverse_lazy("consultas_list")
    title = "Eliminar consulta médica"


# ------- Tratamiento -------
class TratamientoCreate(BaseCreate):
    form_class = TratamientoForm
    success_url = reverse_lazy("tratamientos_list")
    title = "Nuevo tratamiento"

class TratamientoUpdate(BaseUpdate):
    form_class = TratamientoForm
    success_url = reverse_lazy("tratamientos_list")
    title = "Editar tratamiento"

class TratamientoDelete(BaseDelete):
    model = Tratamiento
    success_url = reverse_lazy("tratamientos_list")
    title = "Eliminar tratamiento"


# ------- RecetaMedica -------
class RecetaCreate(BaseCreate):
    form_class = RecetaForm
    success_url = reverse_lazy("recetas_list")
    title = "Nueva receta médica"

class RecetaUpdate(BaseUpdate):
    form_class = RecetaForm
    success_url = reverse_lazy("recetas_list")
    title = "Editar receta médica"

class RecetaDelete(BaseDelete):
    model = RecetaMedica
    success_url = reverse_lazy("recetas_list")
    title = "Eliminar receta médica"


# ------- RecetaMedicamento (detalle) -------
class RecetaDetalleCreate(BaseCreate):
    form_class = RecetaDetalleForm
    success_url = reverse_lazy("receta_detalles_list")
    title = "Nuevo detalle de receta"

class RecetaDetalleUpdate(BaseUpdate):
    form_class = RecetaDetalleForm
    success_url = reverse_lazy("receta_detalles_list")
    title = "Editar detalle de receta"

class RecetaDetalleDelete(BaseDelete):
    model = RecetaMedicamento
    success_url = reverse_lazy("receta_detalles_list")
    title = "Eliminar detalle de receta"
