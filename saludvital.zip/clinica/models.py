"""
=========================================
Módulo: clinica.models
Contexto: EVA2 - Salud Vital Ltda.
Descripción:
- Define el modelo de datos central de la clínica
- Incluye 7 entidades base exigidas por la pauta:
  1) Especialidad
  2) Paciente
  3) Medico
  4) ConsultaMedica
  5) Tratamiento
  6) Medicamento
  7) RecetaMedica
- Relaciones:
  * Medico -> Especialidad (N:1)
  * ConsultaMedica -> Paciente (N:1)
  * ConsultaMedica -> Medico (N:1)
  * Tratamiento -> ConsultaMedica (N:1)
  * RecetaMedica -> ConsultaMedica (N:1)
  * RecetaMedica <-> Medicamento (M:N) con tabla intermedia RecetaMedicamento
- Mejoras requeridas:
  * CHOICES (Paciente.sexo y ConsultaMedica.estado)
  * Nueva tabla adicional (SeguroSalud) con FK en Paciente
=========================================
"""

from django.db import models


# ----------------------------------------
# Tabla adicional: Seguro de Salud / Obra Social
# ----------------------------------------
class SeguroSalud(models.Model):
    """
    Catálogo de Seguros de Salud (Fonasa, Isapre, Particular, etc.)
    """
    nombre = models.CharField(max_length=100, unique=True)
    descripcion = models.TextField(blank=True)

    class Meta:
        ordering = ["nombre"]

    def __str__(self) -> str:
        return self.nombre


# ----------------------------------------
# 1) Especialidad
# ----------------------------------------
class Especialidad(models.Model):
    """
    Especialidad médica (Cardiología, Pediatría, etc.)
    """
    nombre = models.CharField(max_length=120, unique=True)
    descripcion = models.TextField(blank=True)

    class Meta:
        ordering = ["nombre"]

    def __str__(self) -> str:
        return self.nombre


# ----------------------------------------
# 2) Paciente  (MEJORA 1: CHOICES en 'sexo')
# ----------------------------------------
class Paciente(models.Model):
    """
    Información del paciente.
    - Incluye 'sexo' como ChoiceField (MEJORA 1).
    - Incluye FK a SeguroSalud (MEJORA 2).
    """
    SEXO_CHOICES = [
        ("M", "Masculino"),
        ("F", "Femenino"),
        ("X", "Otro/No especifica"),
    ]

    rut = models.CharField(max_length=12, unique=True, help_text="Formato sugerido: 12.345.678-9")
    nombres = models.CharField(max_length=120)
    apellidos = models.CharField(max_length=120)
    sexo = models.CharField(max_length=1, choices=SEXO_CHOICES)
    fecha_nacimiento = models.DateField()
    email = models.EmailField(blank=True)
    telefono = models.CharField(max_length=30, blank=True)
    direccion = models.CharField(max_length=200, blank=True)
    seguro = models.ForeignKey(SeguroSalud, on_delete=models.SET_NULL, null=True, blank=True, related_name="pacientes")

    class Meta:
        ordering = ["apellidos", "nombres"]

    def __str__(self) -> str:
        return f"{self.apellidos}, {self.nombres} ({self.rut})"


# ----------------------------------------
# 3) Medico
# ----------------------------------------
class Medico(models.Model):
    """
    Médico de la clínica, asociado a una especialidad.
    """
    rut = models.CharField(max_length=12, unique=True)
    nombres = models.CharField(max_length=120)
    apellidos = models.CharField(max_length=120)
    email = models.EmailField(blank=True)
    telefono = models.CharField(max_length=30, blank=True)
    especialidad = models.ForeignKey(Especialidad, on_delete=models.PROTECT, related_name="medicos")

    class Meta:
        ordering = ["apellidos", "nombres"]

    def __str__(self) -> str:
        return f"Dr(a). {self.apellidos}, {self.nombres} — {self.especialidad.nombre}"


# ----------------------------------------
# 4) ConsultaMedica  (incluye CHOICES de 'estado')
# ----------------------------------------
class ConsultaMedica(models.Model):
    """
    Registro de una consulta entre un paciente y un médico.
    - Permite filtrar por médico, paciente y especialidad (vía médico o FK directa).
    - 'estado' con CHOICES: pendiente / atendida / cancelada.
    """
    ESTADO_CHOICES = [
        ("PEND", "Pendiente"),
        ("ATEN", "Atendida"),
        ("CANC", "Cancelada"),
    ]

    paciente = models.ForeignKey(Paciente, on_delete=models.PROTECT, related_name="consultas")
    medico = models.ForeignKey(Medico, on_delete=models.PROTECT, related_name="consultas")
    # FK directa a Especialidad (útil para reportes; se puede derivar de medico, pero acelera filtros)
    especialidad = models.ForeignKey(Especialidad, on_delete=models.PROTECT, related_name="consultas")
    fecha_hora = models.DateTimeField()
    motivo = models.TextField()
    diagnostico = models.TextField(blank=True)
    estado = models.CharField(max_length=4, choices=ESTADO_CHOICES, default="PEND")

    class Meta:
        ordering = ["-fecha_hora"]

    def __str__(self) -> str:
        return f"Consulta {self.id} — {self.paciente} con {self.medico} ({self.fecha_hora:%Y-%m-%d %H:%M})"


# ----------------------------------------
# 5) Tratamiento
# ----------------------------------------
class Tratamiento(models.Model):
    """
    Tratamientos indicados en una consulta (reposo, kinesiología, etc.)
    """
    consulta = models.ForeignKey(ConsultaMedica, on_delete=models.CASCADE, related_name="tratamientos")
    nombre = models.CharField(max_length=150)
    indicaciones = models.TextField(blank=True)

    class Meta:
        ordering = ["id"]

    def __str__(self) -> str:
        return f"Tratamiento {self.nombre} (Consulta {self.consulta_id})"


# ----------------------------------------
# 6) Medicamento
# ----------------------------------------
class Medicamento(models.Model):
    """
    Catálogo de medicamentos disponibles para prescripción.
    """
    nombre = models.CharField(max_length=150, unique=True)
    presentacion = models.CharField(max_length=120, blank=True, help_text="Ej.: comprimidos 500mg, jarabe 100ml")
    dosis_sugerida = models.CharField(max_length=120, blank=True)

    class Meta:
        ordering = ["nombre"]

    def __str__(self) -> str:
        return self.nombre


# ----------------------------------------
# 7) RecetaMedica  + tabla intermedia RecetaMedicamento (M:N con atributos)
# ----------------------------------------
class RecetaMedica(models.Model):
    """
    Receta asociada a una consulta. Suele incluir uno o varios medicamentos
    con dosis/posología (almacenado en la tabla intermedia RecetaMedicamento).
    """
    consulta = models.ForeignKey(ConsultaMedica, on_delete=models.CASCADE, related_name="recetas")
    fecha = models.DateField(auto_now_add=True)
    indicaciones_generales = models.TextField(blank=True)

    # Relación M:N a Medicamento, a través de la tabla con atributos
    medicamentos = models.ManyToManyField(Medicamento, through="RecetaMedicamento", related_name="recetas")

    class Meta:
        ordering = ["-fecha"]

    def __str__(self) -> str:
        return f"Receta {self.id} (Consulta {self.consulta_id})"


class RecetaMedicamento(models.Model):
    """
    Tabla intermedia para la relación M:N entre RecetaMedica y Medicamento,
    incluyendo atributos de la prescripción (dosis, frecuencia, duración).
    """
    receta = models.ForeignKey(RecetaMedica, on_delete=models.CASCADE, related_name="detalles")
    medicamento = models.ForeignKey(Medicamento, on_delete=models.PROTECT, related_name="prescripciones")
    dosis = models.CharField(max_length=120, help_text="Ej.: 500 mg")
    frecuencia = models.CharField(max_length=120, help_text="Ej.: cada 8 horas")
    duracion = models.CharField(max_length=120, help_text="Ej.: 7 días")

    class Meta:
        unique_together = ("receta", "medicamento")  # evita duplicados del mismo fármaco en la receta
        ordering = ["id"]

    def __str__(self) -> str:
        return f"{self.medicamento} — {self.dosis}, {self.frecuencia} / {self.duracion}"

# Create your models here.
