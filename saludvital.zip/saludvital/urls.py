from django.contrib import admin
from django.urls import path, include
from django.views.generic import TemplateView 
from rest_framework import permissions
from drf_yasg.views import get_schema_view
from drf_yasg import openapi
from clinica import views_site as pages

schema_view = get_schema_view(
    openapi.Info(
        title="API Clínica Salud Vital",
        default_version='v1',
        description="Documentación interactiva de la API REST de la Clínica Salud Vital Ltda.",
        terms_of_service="https://www.google.com/policies/terms/",
        contact=openapi.Contact(email="soporte@saludvital.cl"),
        license=openapi.License(name="Uso académico - INACAP 2025"),
    ),
    public=True,
    permission_classes=[permissions.AllowAny],
)

urlpatterns = [
    path('admin/', admin.site.urls),

    # API
    path('api/', include('clinica.urls')),

    # Docs
    path('api/docs/', schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),
    path('api/redoc/', schema_view.with_ui('redoc', cache_timeout=0), name='schema-redoc'),

    # Frontend
    path('', TemplateView.as_view(template_name='home.html'), name='home'),
    path('quienes-somos/', TemplateView.as_view(template_name='quienes_somos.html'), name='quienes_somos'),
    path('servicios/', TemplateView.as_view(template_name='servicios.html'), name='servicios'),
    path('contacto/', TemplateView.as_view(template_name='contacto.html'), name='contacto'),

        # --- Datos del sistema (HTML, fuera del admin y fuera de la API) ---
    path('seguros/', pages.seguros_list, name='seguros_list'),
    path('especialidades/', pages.especialidades_list, name='especialidades_list'),
    path('pacientes/', pages.pacientes_list, name='pacientes_list'),
    path('medicos/', pages.medicos_list, name='medicos_list'),
    path('medicamentos/', pages.medicamentos_list, name='medicamentos_list'),
    path('consultas/', pages.consultas_list, name='consultas_list'),
    path('tratamientos/', pages.tratamientos_list, name='tratamientos_list'),
    path('recetas/', pages.recetas_list, name='recetas_list'),
    path('receta-detalles/', pages.receta_detalles_list, name='receta_detalles_list'),

     path('datos/', TemplateView.as_view(template_name='data/index.html'), name='datos'),

path('seguros/nuevo/', pages.SeguroCreate.as_view(), name='seguro_create'),
    path('seguros/<int:pk>/editar/', pages.SeguroUpdate.as_view(), name='seguro_update'),
    path('seguros/<int:pk>/eliminar/', pages.SeguroDelete.as_view(), name='seguro_delete'),

    # --- CRUD Especialidad ---
    path('especialidades/nuevo/', pages.EspecialidadCreate.as_view(), name='especialidad_create'),
    path('especialidades/<int:pk>/editar/', pages.EspecialidadUpdate.as_view(), name='especialidad_update'),
    path('especialidades/<int:pk>/eliminar/', pages.EspecialidadDelete.as_view(), name='especialidad_delete'),

    # --- CRUD Paciente ---
    path('pacientes/nuevo/', pages.PacienteCreate.as_view(), name='paciente_create'),
    path('pacientes/<int:pk>/editar/', pages.PacienteUpdate.as_view(), name='paciente_update'),
    path('pacientes/<int:pk>/eliminar/', pages.PacienteDelete.as_view(), name='paciente_delete'),

    # --- CRUD Medico ---
    path('medicos/nuevo/', pages.MedicoCreate.as_view(), name='medico_create'),
    path('medicos/<int:pk>/editar/', pages.MedicoUpdate.as_view(), name='medico_update'),
    path('medicos/<int:pk>/eliminar/', pages.MedicoDelete.as_view(), name='medico_delete'),

    # --- CRUD Medicamento ---
    path('medicamentos/nuevo/', pages.MedicamentoCreate.as_view(), name='medicamento_create'),
    path('medicamentos/<int:pk>/editar/', pages.MedicamentoUpdate.as_view(), name='medicamento_update'),
    path('medicamentos/<int:pk>/eliminar/', pages.MedicamentoDelete.as_view(), name='medicamento_delete'),

    # --- CRUD Consulta ---
    path('consultas/nuevo/', pages.ConsultaCreate.as_view(), name='consulta_create'),
    path('consultas/<int:pk>/editar/', pages.ConsultaUpdate.as_view(), name='consulta_update'),
    path('consultas/<int:pk>/eliminar/', pages.ConsultaDelete.as_view(), name='consulta_delete'),

    # --- CRUD Tratamiento ---
    path('tratamientos/nuevo/', pages.TratamientoCreate.as_view(), name='tratamiento_create'),
    path('tratamientos/<int:pk>/editar/', pages.TratamientoUpdate.as_view(), name='tratamiento_update'),
    path('tratamientos/<int:pk>/eliminar/', pages.TratamientoDelete.as_view(), name='tratamiento_delete'),

    # --- CRUD Receta ---
    path('recetas/nuevo/', pages.RecetaCreate.as_view(), name='receta_create'),
    path('recetas/<int:pk>/editar/', pages.RecetaUpdate.as_view(), name='receta_update'),
    path('recetas/<int:pk>/eliminar/', pages.RecetaDelete.as_view(), name='receta_delete'),

    # --- CRUD Receta Detalle ---
    path('receta-detalles/nuevo/', pages.RecetaDetalleCreate.as_view(), name='recetadetalle_create'),
    path('receta-detalles/<int:pk>/editar/', pages.RecetaDetalleUpdate.as_view(), name='recetadetalle_update'),
    path('receta-detalles/<int:pk>/eliminar/', pages.RecetaDetalleDelete.as_view(), name='recetadetalle_delete'),
]